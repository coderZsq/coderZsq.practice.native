//
//  Foo.m
//  debug-objc
//
//  Created by 朱双泉 on 2020/10/1.
//

#import "Foo.h"

@implementation Foo

+ (void)load {
    
}

@end
