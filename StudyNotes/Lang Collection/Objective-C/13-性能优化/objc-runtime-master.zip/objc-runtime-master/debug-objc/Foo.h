//
//  Foo.h
//  debug-objc
//
//  Created by 朱双泉 on 2020/10/1.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Foo : NSObject

@end

NS_ASSUME_NONNULL_END
