#include "base.h"

class Baz {
public:
	Baz() { bazInitied = true; }
	~Baz() { bazTeminated = true; }

};


Baz baz;

