#ifndef __NSFileCoordinator_h_GNUSTEP_BASE_INCLUDE
#define __NSFileCoordinator_h_GNUSTEP_BASE_INCLUDE

#import <Foundation/NSObject.h>

#if OS_API_VERSION(MAC_OS_X_VERSION_10_7,GS_API_LATEST)

@interface NSFileAccessIntent : NSObject
@end

@interface NSFileCoordinator : NSObject
@end

#endif
#endif
